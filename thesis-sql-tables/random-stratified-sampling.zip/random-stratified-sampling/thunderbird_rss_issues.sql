-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 10:16 AM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Issue_Trackers`
--

-- --------------------------------------------------------

--
-- Table structure for table `thunderbird_rss_issues`
--

CREATE TABLE `thunderbird_rss_issues` (
  `issue_id` int(11) NOT NULL,
  `title` text,
  `reporter` text,
  `assignee` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thunderbird_rss_issues`
--

INSERT INTO `thunderbird_rss_issues` (`issue_id`, `title`, `reporter`, `assignee`) VALUES
(9, 'Identity detection should be based on Envelope-To', 'web', 'nobody'),
(25, 'X-Sender address in header from another account in Thunderbird', 'toathoudt', 'nobody'),
(53, 'gmail All Mail syncs even though it is set in account settings to not sync', 'udippel', 'nobody'),
(54, 'Unexpected changes to whether email bodies stored locally for imap account folders', 'gds', 'nobody'),
(56, 'Allow setting width of the account creation wizard dialog for localized versions of Thunderbird', 'bpiec', 'acelists'),
(80, 'creating news server account does not lead user to full server settings', 'robertmiles', 'nobody'),
(99, '&apos;Add account wizard&apos; should give end user instructions in case autodetection fails', 'hartnegg', 'acelists'),
(114, 'Tibetan sorting doesn&apos;t work in Address Book (Windows 7).  Ability to choose font would be nice too.', 'snow77', 'nobody'),
(129, 'Create MetaSearch rank order via Prefs for Address Autocomplete', 'educmale', 'nobody'),
(153, 'When dragging an existing entry from Address Book to a List the complete entry is not moved', 'hgruenberg', 'nobody'),
(192, '[meta][VUW 2016] Address book Ensemble Project', 'david', 'nobody'),
(222, '[am] Add Amharic localisation to Thunderbird', 'dwayne', 'nobody'),
(267, 'Filelink: Add account auto config', 'jb', 'nobody'),
(283, 'Cannot delete nor move messages when compact option is on', 'jarkap', 'nobody'),
(308, 'Message filters with invalid HTML body not working', 'robert', 'nobody'),
(332, 'Apply filter to URLs in message body', 'giovanni.gozzi', 'nobody'),
(333, 'Quick filter by body doesn&apos;t find message if message stored in IMAP folder', 'greenrd', 'nobody'),
(344, 'Incorrect synchronization of moved items to IMAP server', 'dami', 'nobody'),
(370, 'Enlarge click area of folder tree twisty/arrow to the left ([+][-],[>][v])', 'juergen.stengele', 'nobody'),
(371, 'Keyboard shortcuts always inactive', 'jstas13', 'nobody'),
(380, 'List of messages is buggy in unified folder view, especially when moving/hovering the mouse over the unified thread pane', 'vincent', 'nobody'),
(390, 'delete messages from IMAP does not work', 'traut', 'nobody'),
(415, 'some .msf files get lost after Thunderbird restart', 'mschark', 'nobody'),
(424, 'message contents disappear after deleting an imap folder', 'lucien.gentis', 'nobody'),
(425, 'Columns  not remembered in the message list after restart (only after restart of Tb which is automatically initiated when an update is applied by Addon update). Caused by add-on/extension', 'cstef', 'nobody'),
(435, 'threading breaks on save in Drafts folder', 'ossman', 'nobody'),
(490, 'Thunderbird 38.1.0 lost message folders', 'lstout', 'nobody'),
(544, 'Attachments seem to be corrupted even tho they are not.', 'seo', 'nobody'),
(571, 'Code clean-up: Style nits, typos and trailing spaces - take 2', 'jorgk', 'nobody'),
(572, 'Please add Khmer (km) to Thunderbird for the release of 38', 'sokhem', 'philipp'),
(577, 'Drag and Drop Mozmill failure 2017-09-08: 7 failures (Friday bustage)', 'jorgk', 'nobody'),
(580, 'TEST-UNEXPECTED-FAIL | C:slave	estuild	estsmozmillmigration-to-rdf-ui-2	est-migrate-to-rdf-ui-2.js | test-migrate-to-rdf-ui-2.js::test_width_persisted', 'jorgk', 'nobody'),
(587, 'TEST-UNEXPECTED-FAIL | /builds/slave/test/build/tests/mozmill/content-tabs/test-plugin-crashing.js | test-plugin-crashing.js::test_crashed_plugin_notification_inline', 'rkent', 'acelists'),
(594, 'Clicking on new e-mail in the notifier may use the wrong window/tab', 'mi+mozilla', 'nobody'),
(624, 'crash in nsDocumentViewer::OnDonePrinting @ address 0x5a5a5a5a/e5e5e5e9', 'vseerror', 'nobody'),
(628, 'Inserting image into mail causes crash @ @0x0 | CProfferService::QueryService', 'bill', 'nobody'),
(634, 'tb 38.1.0 D3D11 related crash in driver for Nvidia Geforce 740M on startup when HWA, layers.acceleration and gfx.direct2d, are enabled', 'marnick.leau', 'nobody'),
(635, 'ASSERTION: URI is empty: &apos;!aURI.IsEmpty()&apos;, file /TB-NEW/TB-3HG/new-src/mozilla/rdf/base/src/nsRDFService.cpp, line 884', 'ishikawa', 'nobody'),
(642, 'crash in nsImapIncomingServer::GetMsgFolderFromURI [Mac]', 'vseerror', 'nobody'),
(643, 'Lightning uninstalls itself on every minor Thunderbird upgrade', 'bugzilla-mozilla', 'nobody'),
(682, 'Add method to get standard input from command line', 'abspack', 'nobody'),
(686, 'Extremely slow during writing operations onto a NAS since Windows 10 upgrade', 'kai.o.mueller', 'nobody'),
(691, 'Smeared Fonts and Images with ATI Radeon HD 4800', 'axelg', 'nobody'),
(725, 'HTML text cut/copied from one composition (reply to received email message) cannot be pasted into new composition window', 'derek', 'nobody'),
(771, 'View Source All Indented due to Lack of Line Numbers', 'wvsrk1lx', 'nobody'),
(802, 'Thunderbird 52.2.0-1 on Arch Linux (4.11.5-1-ARCH) crashes when user clicks on a contact in the chat tab', 'bugzilla', 'nobody'),
(818, 'Daily chat client should not ask for an SSL certificate when connecting to a server through SSL.', 'ntrrgc', 'nobody'),
(834, 'Show contacts groups for XMPP', 'yjsosa', 'nobody'),
(835, 'Feature request: Quick search in chat contacts', 'lihlii64', 'nobody'),
(871, 'New Message Notification pop-up window not working (but worked before)', 'peter_ludwig', 'nobody'),
(919, 'Font spongy if switching external display(s) to internal on Notebook', 'jogi', 'nobody'),
(962, 'Activity Manager not showing failed/failing imap activity', 'mitra_lists', 'nobody'),
(995, 'Uncaught exceptions during Thunderbird shutdown', 'irving', 'nobody'),
(1019, 'compose body isn&apos;t actually ready (images not yet converted to data:) when NotifyComposeBodyReady event is triggered', 'jik', 'nobody'),
(1038, 'Thunderbird 24 Beta 2 does not respect reply-to header', 'cadeyrn', 'nobody'),
(1039, 'Mailto link in HTML email becomes duplicated e-mail address in plain text email', 'theant', 'nobody'),
(1047, 'rewrap produces inconsistent results', 'steve.chessin', 'nobody'),
(1049, 'LDAP search/autocomplete using SSL doesn&apos;t work for TB 31.0 any loger, without SSL it still works.', 'reinfried.o.peter', 'nobody'),
(1079, 'Hardware acceleration may cause message compose window to lag severely (in unknown circumstances)', 'rob.smeets', 'nobody'),
(1133, 'Reply-All sometimes replies only to sender with only sender wrote: in message body', 'shaunc', 'nobody'),
(1143, 'Delete key changes formatting in prior text instead of removing line break after', 'firstpeterfourten', 'nobody'),
(1160, 'Text wrongly marked as quoted when composing a reply', 'allo', 'nobody'),
(1176, 'Copy or cut and paste removes spaces within write window of Thunderbird', 'wb6yru', 'nobody'),
(1185, 'Fix to e-mail addresses that have a &apos; (MS Outlook 2013)', 'marcoagpinto', 'nobody'),
(1202, 'Removing text in the HTML composer changes current font', 'babystyle', 'nobody'),
(1209, 'Ctrl+drag moves selected text (instead of copying) on Linux', 're', 'nobody'),
(1217, 'Full Screen Mail Compose window not closed after sending mail (OS X 10.8)', 'jasonyeo88', 'nobody'),
(1224, 'rewrap destroys newline character', 'krichter722', 'nobody'),
(1257, 'Emails sent to wrong recipients', 'galpeaceman', 'nobody'),
(1355, 'Linkify text-only URLs e.g. http://foo.bar in HTML messages when shown in message reader', 'mstanke', 'nobody'),
(1364, 'impossible to copy-paste parts of a link without visiting it.  text select opens link', 'mozilla', 'nobody'),
(1375, 'base64 encoded email even in text-only view causes 100% cpu load and never displays, hangs gui and thunderbird.exe process completely', 'abittner', 'nobody'),
(1388, 'When ICS attached, Lightning enabled ONLY event is visible not the email', 'jobst', 'nobody'),
(1404, 'Provide user interface for Gmail labels (X-GM-LABELS)', 'david', 'nobody'),
(1405, 'unexpected inheritance of colors through tables in thunderbird html mails', 'mads', 'nobody'),
(1443, 'BiDi Mail UI direction auto-detection busted by recent(ish) changes', 'avner.falk', 'nobody'),
(1445, 'When performing a Mail import from the Tools menu of the Thunderbird application, after choosing either Outlook or Outlook express the user is not prompted to select the folders that is desired to be imported.  Instead it imports all the mail folders.', 'emulator64', 'nobody'),
(1481, 'C-C ldap directory: fix -Werror=sign-compare: signed vs unsigned warnings (now treated as errors)', 'ishikawa', 'ishikawa'),
(1484, 'We don&apos;t register Thunderbird as the default .eml handler on Mac', 'standard8', 'nobody'),
(1487, 'new mail notification taskbar icon remains on program exit', 'kuno.meyer', 'nobody'),
(1535, 'Add UI for clearing Visited Link/Browsing History when Thunderbird closes', 'dstrickl', 'nobody'),
(1542, 'Large number of tags causes very bad tags preference UI performance (from autotaging RSS feeds)', 'acarrico', 'nobody'),
(1572, 'imap messages archived to local folders still indexed on Inbox, not on archive folder [faceted search results]  (fixed by rebuilding gloda database)', 'fpvolquind', 'nobody'),
(1603, 'Quick filter UI is unresponsive after a quick search triggers', 'chealer', 'nobody'),
(1606, 'Crash in nsMsgSearchTerm::MatchString / nsMsgSearchTerm::MatchRfc2047String', 'opera.wang', 'nobody'),
(1607, 'Crash in nsDocumentOpenInfo::OnStartRequest', 'bob', 'nobody'),
(1611, 'gloda implications of indexing / downloading email with hundreds of email addresses, memory usage rises to ~300MB/sec until it crashes', 'danieleds0', 'nobody'),
(1635, 'S/MIME signature wrongly reported as invalid', 'peter.kahl', 'nobody'),
(1705, 'Upgrade of Thunderbird to 45.2 Password handshake fails', 'stevet', 'nobody'),
(1712, 'timeout / popup failures in thunderbird mozmill test: lack of proper synchronization in test programs', 'ishikawa', 'nobody'),
(1728, 'Thunderbird does not display strong plain text tag correctly.', 'etirta', 'nobody'),
(1734, 'Chat - ugly border around avatar on the right', 'bugs', 'nobody'),
(1760, 'Toolbar in message-header pane lacks icons present in the main toolbar, no longer accessible in a message tab', 'rsx11m.pub', 'nobody'),
(1763, 'menu bar should be on top - not inside tab', 'mkmelin+mozilla', 'nobody'),
(1799, 'GUI bug: emails don&apos;t appear in local inbox thread pane, but do appear in global inbox thread pane.', 'thecrap', 'nobody'),
(1832, 'Almost impossible to write a new email (system unresponsive) while many new messages to be synchronised from IMAP server', 'A.Finch', 'nobody'),
(1849, 'imap emails re-download constantly for all accounts; summary inbox error message', 'pcinfo', 'nobody'),
(1871, 'Multiple draft copies saved', 'epaine', 'nobody'),
(1881, '&apos;Always prefer display name over message header&apos; not always honoured for at least one address', 'najoll', 'nobody'),
(1956, 'unable to overwrite functions in addons with dom.compartment_per_addon = true', 'intendentedelleacque', 'nobody');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `thunderbird_rss_issues`
--
ALTER TABLE `thunderbird_rss_issues`
  ADD PRIMARY KEY (`issue_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
