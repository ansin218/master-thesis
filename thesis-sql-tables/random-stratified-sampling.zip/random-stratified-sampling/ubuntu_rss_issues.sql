-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 10:18 AM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Issue_Trackers`
--

-- --------------------------------------------------------

--
-- Table structure for table `ubuntu_rss_issues`
--

CREATE TABLE `ubuntu_rss_issues` (
  `issue_id` int(11) NOT NULL,
  `title` text,
  `reporter` text,
  `assignee` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ubuntu_rss_issues`
--

INSERT INTO `ubuntu_rss_issues` (`issue_id`, `title`, `reporter`, `assignee`) VALUES
(1738, 'System lock on upgrade or new install', 'WalterBanks', 'Unassigned'),
(1798, '[KM400]xserver/openchrome crash with unichrome', 'Teknics', 'BartoszKosiorek'),
(1960, '\n    sort -u erase some utf8 characters\n', 'AnYang', 'langpack-locales(Ubuntu)'),
(1982, 'cannot play video, complains about missing support for Quicktime', 'Martin-ÉricRacine', 'Unassigned'),
(2012, 'performance of accounts-daemon is very poor', 'PeterGray', 'accountsservice(Ubuntu)'),
(2168, '\n    kernel crash on EC2 raring\n', 'ScottMoser', 'Unassigned'),
(2303, 'rt2800 crash on skb_push, apparently underflows the skb area', 'AnttiS.Lankila', 'Unassigned'),
(2317, 'After installation hitting enter to reboot the system after cd ejects fails', 'DaveMorley', 'Unassigned'),
(2361, '\n    webbrowser-app does not start in Unity 8 preview session\n', 'OlliRies', 'ChrisCoulson'),
(2461, 'Base Grid units on the gsettings key per monitor', 'PatMcGowan', 'Unassigned'),
(2620, 'Ubuntu 15.04 - Macbook Pro Early 2015 (12,1) no 5 GHz wireless', 'Jrddvs', 'Unassigned'),
(2992, '\n    python-apt in yakkety no longer creates partial\n', 'SergioSchvezov', 'SergioSchvezov'),
(3064, '\n    virtualbox+usb 3.0 breaks boot, -28 kernel works\n', 'LubosKosco', 'KamalMostafa'),
(3088, 'stress-ng memory testing causes Arm64 system to hang', 'JeffLane', 'Unassigned'),
(3131, 'Xmir -rootless: Firefox menus pop up then close right away', 'BrandonSchaefer', 'StephenM.Webb'),
(3198, 'Consistent boot time kernel panic', 'ShaharOr', 'JosephSalisbury'),
(3272, '\n    linux-aws/linux-gke incorrectly producing and using linux-*-tools-common/linux-*-cloud-tools-common\n', 'AndyWhitcroft', 'AndyWhitcroft'),
(3382, '\n    Synaptic has memory leaks\n', 'GermánPoo-Caamaño', 'Unassigned'),
(3540, '[apport] blam.exe crashed with SIGSEGV', 'Sunn3K7aas', 'Unassigned'),
(3551, '[apport] oem-config-dm crashed with XStartupError in run()', 'miked', 'Unassigned'),
(3717, 'Can\'t use the lowest brightness setting', 'unggnu', 'linux(Ubuntu)'),
(3804, 'glade-3 break  when open a .glade file', 'JaysonReis', 'gtk+2.0(Ubuntu)'),
(3853, '\n    nautilus hangs when unmounting an nfs disk if nfs server is down\n', 'AntoinePairet', 'nautilus(Ubuntu)'),
(4044, 'file-roller crashed with SIGSEGV in gtk_propagate_event()', 'pitwalker', 'file-roller(Ubuntu)'),
(4206, 'Login sound is too loud and disruptive on first boot', 'steverweber', 'Unassigned'),
(4573, 'mountall ignores nofail mount option', 'Artem', 'Unassigned'),
(4876, '\n    ssh-add does not always unlock ssh keys\n', 'ClaudioMoretti', 'Unassigned'),
(4885, '[Upstream] Deleting a column in Writer deletes whole table', 'Leandro', 'OpenOffice'),
(4911, '\n    TRIM support not enabled for SSDs\n', 'EduardHasenleithner', 'Unassigned'),
(4921, 'Yelp causes 100% CPU usage', 'BillRichman', 'yelp(Ubuntu)'),
(5138, '8086:10c9 bridged network interface dropping RX packets', 'TamasPapp', 'Unassigned'),
(5324, 'mythtv-backend needs to run in writable directory', 'BrianJ.Murrell', 'ThomasMashos'),
(5540, 'flac crashed with SIGFPE', 'Fr-coord', 'Unassigned'),
(5759, '\n    [serial] use hw flow control if supported\n', 'dannfrazier', 'Unassigned'),
(5805, 'gnome-shell crashed with SIGABRT in g_assertion_message()', 'Raul', 'gnome-shell(Ubuntu)'),
(5834, 'mysql plugins fail on mysql 5.5/5.6', 'Hans-JoachimKliemeck', 'Unassigned'),
(6050, 'CVE-2014-0131', 'JohnJohansen', 'Unassigned'),
(6155, '\n    lpfc driver needs to be updated.\n', 'DickKennedy', 'Unassigned'),
(6280, 'Low performance when using vlan over VxLan', 'KamalHeib', 'DraganS.'),
(6292, 'Minicom opening serial but not input shown', 'Cristiano', 'Unassigned'),
(6293, '\n    WARNING: CPU: 1 PID: 207 at /build/linux-lts-vivid-3x86XO/linux-lts-vivid-3.19.0/drivers/gpu/drm/i915/intel_display.c:958\n', 'CB', 'Unassigned'),
(6394, 'CVE-2015-8019', 'SteveBeattie', 'Unassigned'),
(6426, '\n    Screen doesn\'t change after connecting a BT mouse and no cursor displayed.\n', 'CarolineYu', 'Unassigned'),
(6813, 'package upgrade broken for multipath system, specifically ppc64el', 'BradFigg', 'Unassigned'),
(6879, 'can\'t change sensitivity on (new) Alps trackstick', 'Michael', 'Unassigned'),
(7256, 'Extremely long URLs don\'t display properly', 'AdamMcMaster', 'firefox(Ubuntu)'),
(7307, 'Splashy continues to conflict with usplash and thus fails to start despite removing usplash startup links', 'AndreaFerraresi', 'Unassigned'),
(7634, 'Screenlets hide on show desktop without compiz', 'OlegVaskevich', 'Unassigned'),
(7693, 'Qalculate SIGABRTs with exp($large_number)', 'AlexanderJones', 'libqalculate(Ubuntu)'),
(7844, 'Permission denied running splitconfig.pl when running debian/rules updateconfigs', 'FabriceCoutadeur', 'Unassigned'),
(8073, 'Appearance Preferences GUI White Space Problem', 'nullack', 'gnome-control-center'),
(8114, 'Gnome print dialog too big for 1024*600 resolution', 'Jean-Nono', 'Unassigned'),
(8146, 'transmission downloads portions of files I\'ve unselected in the torrent', 'CyrilleGrosdemange', 'transmission(Ubuntu)'),
(8561, 'CVE-2012-2373', 'JohnJohansen', 'Unassigned'),
(9270, 'Smarty in php.ini Include', 'GregTaylor', 'smarty(Ubuntu)'),
(9535, 'Thunderbird should use a local startpage', 'AlexanderSack', 'Unassigned'),
(9941, 'Make fullscreen pan if remote display has higher resolution', 'KevinOtte', 'vinagre(Ubuntu)'),
(10585, '[needs packaging] gxmame', 'AntónioLima', 'Ubuntu'),
(10916, 'Key bindng for Back and Forward functionality', 'JeenuV', 'evince(Ubuntu)'),
(11299, '[needs-packaging] Create package: Acsal', 'Ansus', 'ChristophKorn'),
(11402, 'Xorg misbehaves when user home directory is missing', 'PaulReiber', 'Unassigned'),
(12128, 'Unity quicklists should be theme able', 'NiklasRosenqvist', 'Unassigned'),
(12222, 'No support for power management', 'dronus', 'Unassigned'),
(12295, 'use symbolic icons', 'AndreaCimitan', 'Unassigned'),
(12965, 'jaunty wicd wpa2 constant reconnect', 'Matt', 'AdamBlackburn'),
(13053, 'cannot launch install', 'kelate', 'Unassigned'),
(13304, 'system freeze on facebook surfing', 'imoas83', 'firefox-3.0(Ubuntu)'),
(13430, 'Firefox is flickering elements, drawing random lines, and other artifacts.', 'CameronPorter', 'Unassigned'),
(14420, 'Black dots appear on screen', 'ruru', 'Unassigned'),
(14954, 'Hauppauge HVR-1600 Remote Not Detected', 'bsntech', 'Unassigned'),
(15044, '\n    udev-configure-printer /invalid or missing IEEE 1284 Device ID \n', 'starslights', 'Unassigned'),
(15458, 'usb audio driver can still be loaded first despite settings in /etc/modprobe.d/alsa-base.conf', 'ReubenThomas', 'DanielTChen'),
(16231, 'Vimicro Corp. Venus USB 2.0 webcam not detected [WORKAROUND]', 'BBobo', 'Unassigned'),
(16572, 'Mdadm array fails to assemble on boot.', 'teeedubb', 'Unassigned'),
(16764, 'mumble doesn\'t recognize hotplugged external USB keyboard for shortcuts', 'SteveBeattie', 'ThorvaldNatvig'),
(17340, '\n    PCM mixer too high / distortion - HDA Intel: Conexant CX20551 (Waikiki)\n', 'ChrisWyatt', 'DanielTChen'),
(17512, 'gtk-missing-image is missing', 'Allo', 'Unassigned'),
(17705, 'Recommended packages are excessive', 'mlissner', 'IgnaceMouzannar'),
(18237, 'upstart fails to upgrade from hardy to lucid (--configure)', 'RolfLeggewie', 'Unassigned'),
(18707, '\n    javascript toLocaleDateString output format YY-MM-YYYY\n', 'PhilDuby', 'Unassigned'),
(19354, 'weather applet loses connectivity permanently', 'TrentMcPheron', 'onox'),
(19930, 'rsyslogd fails to load lmnsd_gtls.so', 'MarkMerritt', 'Unassigned'),
(20122, '100% CPU usage in init if /dev/console is not available', 'CedricSchieli', 'Unassigned'),
(20232, 'Banshee library watcher should be enabled by default', 'vervelover', 'Unassigned'),
(20911, 'Half screen display on primary when extending', 'Josh', 'Unassigned'),
(21713, 'Kubuntu 12.04 doesn\'t logout/reboot/shutdown', 'estolle', 'Unassigned'),
(22768, '\n    LightDM KDE Greeter loads the desktop half a minute after login\n', 'EliasKouskoumvekakis', 'Unassigned'),
(23003, 'xrandr : Failed to get size of gamma for output default', 'cwsnyder', 'Unassigned'),
(24706, 'Ubuntu 13.10, Thinkpad x230, Fn keys not working after upgrade', 'AndersHall', 'Unassigned'),
(25027, 'No sound with HDA Intel, VIA VT8237A/VT8251, kernel 3.12', 'hr', 'alsa-driver(Ubuntu)'),
(25059, 'No Autohide Launcher Bar Mouse Reveal on Secondary Monitor', 'WilliamO\'Meallain', 'Unassigned'),
(25071, 'Error loading shared library for smart card authentication to server', 'AndrewR.Orndorff', 'Unassigned'),
(25607, 'stardict-tools doesn\'t allow duplicate keys', 'ChristianHildmann', 'stardict-tools(Ubuntu)'),
(25719, 'haveged consumes 100% cpu when used with -w > 4067', 'benthielsen', 'Unassigned'),
(25783, 'No buttons in shut down menu on login page', 'DanHawke', 'Unassigned'),
(26755, '[OTA13- notification panel]no apps listed', 'wilfridd', 'BillFiller'),
(26757, 'yakkety compiling failed on ubuntu trusty', 'LongQuanSha', 'Unassigned'),
(26964, '\n    gnome-terminal crashes when tab is dragged onto another tab\'s terminal area\n', 'Redfern-derek', 'GTK+'),
(27786, 'Distorted menus in a lot of Qt apps under Unity8', 'dinamic', 'Unassigned'),
(28249, 'Intel i40e PF reset under load', 'JayVosburgh', 'JayVosburgh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ubuntu_rss_issues`
--
ALTER TABLE `ubuntu_rss_issues`
  ADD PRIMARY KEY (`issue_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
