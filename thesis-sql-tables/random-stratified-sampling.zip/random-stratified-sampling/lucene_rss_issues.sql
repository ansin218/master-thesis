-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 10:09 AM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Issue_Trackers`
--

-- --------------------------------------------------------

--
-- Table structure for table `lucene_rss_issues`
--

CREATE TABLE `lucene_rss_issues` (
  `issue_id` int(11) NOT NULL,
  `title` text,
  `reporter` text,
  `assignee` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lucene_rss_issues`
--

INSERT INTO `lucene_rss_issues` (`issue_id`, `title`, `reporter`, `assignee`) VALUES
(44, '[LUCENE-7888] Test{Mixed,Binary}DocValuesUpdates.testManyReopensAndFields() failures', 'Steve Rowe', 'Michael McCandless'),
(48, '[LUCENE-7883] Remove references to Thread#getContextClassLoader() from Lucene/Solr codebase', 'Uwe Schindler', 'Uwe Schindler'),
(147, '[LUCENE-7755] Join queries should not reference IndexReaders.', 'Adrien Grand', 'Unassigned'),
(258, '[LUCENE-7631] Enforce javac warnings', 'Mike Drob', 'Unassigned'),
(273, '[LUCENE-7615] SpanSynonymQuery', 'Paul Elschot', 'Unassigned'),
(432, '[LUCENE-7434] Add minNumberShouldMatch parameter to SpanNearQuery', 'Tim Allison', 'Unassigned'),
(463, '[LUCENE-7401] BKDWriter should ensure all dimensions are indexed', 'Adrien Grand', 'Unassigned'),
(508, '[LUCENE-7352] TestSimpleExplanationsWithFillerDocs failures', 'Steve Rowe', 'Unassigned'),
(509, '[LUCENE-7351] BKDWriter should compress doc ids when all values in a block are the same', 'Adrien Grand', 'Unassigned'),
(527, '[LUCENE-7331] GeoPointTestQuery should use GeoTestUtil instead of GeoPointTestUtil', 'Nicholas Knize', 'Unassigned'),
(563, '[LUCENE-7291] HeatmapFacetCounter bug with dateline and large non-point shapes', 'David Smiley', 'David Smiley'),
(583, '[LUCENE-7264] Fewer conditionals in DocIdSetBuilder.add', 'Adrien Grand', 'Adrien Grand'),
(645, '[LUCENE-7197] Geo3DPoint test failure', 'Karl Wright', 'Karl Wright'),
(648, '[LUCENE-7194] Ban Math.toRadians/toDegrees and remove all usages of it', 'Robert Muir', 'Karl Wright'),
(749, '[LUCENE-7085] PointRangeQuery.equals does not work', 'Adrien Grand', 'Michael McCandless'),
(827, '[LUCENE-6995] Add branch change trigger to common-build.xml to keep sane build on GIT branch change', 'Uwe Schindler', 'Uwe Schindler'),
(920, '[LUCENE-6894] Improve DISI.cost() by assuming independence for match probabilities', 'Paul Elschot', 'Unassigned'),
(982, '[LUCENE-6821] TermQuery\'s constructors should clone the incoming term', 'Adrien Grand', 'Tommaso Teofili'),
(1102, '[LUCENE-6680] BlendedInfixSuggester dedup bug', 'Arcadius Ahouansou', 'Unassigned'),
(1136, '[LUCENE-6641] Idea CodeSyle should be enriched', 'Alessandro Benedetti', 'Unassigned'),
(1229, '[LUCENE-6542] FSDirectory throws AccessControlException unless you grant write access to the index', 'Trejkaz', 'Uwe Schindler'),
(1244, '[LUCENE-6526] Make AssertingWeight check that scores are not computed when needsScores is false', 'Adrien Grand', 'Adrien Grand'),
(1347, '[LUCENE-6413] Test runner should report the number of suites completed/ remaining', 'Dawid Weiss', 'Dawid Weiss'),
(1354, '[LUCENE-6405] BaseXXXFormatTestCase should test exception handling.', 'Robert Muir', 'Unassigned'),
(1370, '[LUCENE-6388] Optimize SpanNearQuery', 'Robert Muir', 'Unassigned'),
(1422, '[LUCENE-6329] Calling score() should be ok even if needsScores is false', 'Adrien Grand', 'Adrien Grand'),
(1426, '[LUCENE-6325] improve perf and memory of FieldInfos.fieldInfo(int)', 'Robert Muir', 'Michael McCandless'),
(1444, '[LUCENE-6304] Add MatchNoDocsQuery that matches no documents', 'Lee Hinman', 'Unassigned'),
(1508, '[LUCENE-6233] CheckIndex is dog slow when checking term vectors', 'Michael McCandless', 'Michael McCandless'),
(1583, '[LUCENE-6149] Infix suggesters\' highlighting, allTermsRequired options are hardwired and not configurable for non-contextual lookup', 'Boon Low', 'Tomás Fernández Löbbe'),
(1611, '[LUCENE-6119] Add auto-io-throttle to ConcurrentMergeScheduler', 'Michael McCandless', 'Michael McCandless'),
(1683, '[LUCENE-6043] Add backcompat support for UAX29URLEmailTokenizer before 4.7', 'Ryan Ernst', 'Ryan Ernst'),
(1716, '[LUCENE-6007] Failed attempt of downloading javax:activation javadoc', 'Ilia Sretenskii', 'Steve Rowe'),
(1722, '[LUCENE-6001] DrillSideways throws NullPointerException for some searches', 'Dragan Jotanovic', 'Unassigned'),
(1751, '[LUCENE-5968] Improve error message when \'ant beast\' is run on top-level modules', 'Ramkumar Aiyengar', 'Uwe Schindler'),
(1753, '[LUCENE-5965] Make CorruptIndexException require \'resource\' like TooOld/TooNew do', 'Robert Muir', 'Unassigned'),
(1755, '[LUCENE-5963] Improved AnalyzingSuggester.replaceSep()', 'Markus Heiden', 'Michael McCandless'),
(1785, '[LUCENE-5931] DirectoryReader.openIfChanged(oldReader, commit) incorrectly assumes given commit point has deletes/field updates', 'Vitaly Funstein', 'Michael McCandless'),
(1818, '[LUCENE-5892] Make CharsRefBuilder implement Appendable', 'Adrien Grand', 'Adrien Grand'),
(1868, '[LUCENE-5837] Only check docsWithField when necessary in numeric comparators', 'Adrien Grand', 'Adrien Grand'),
(1904, '[LUCENE-5796] Scorer.getChildren() can throw or hide a subscorer for some boolean queries', 'Terry Smith', 'Unassigned'),
(1924, '[LUCENE-5775] JaspellTernarySearchTrie.ramBytesUsed hits StackOverflowError', 'Michael McCandless', 'Michael McCandless'),
(2113, '[LUCENE-5563] Remove sep layout', 'Robert Muir', 'Unassigned'),
(2136, '[LUCENE-5538] FastVectorHighlighter fails with booleans of phrases', 'Robert Muir', 'Unassigned'),
(2296, '[LUCENE-5362] IndexReader and friends should check ref count when incrementing', 'Simon Willnauer', 'Simon Willnauer'),
(2297, '[LUCENE-5361] FVH throws away some boosts', 'Nik Everett', 'Adrien Grand'),
(2357, '[LUCENE-5293] Also use EliasFanoDocIdSet in CachingWrapperFilter', 'Paul Elschot', 'Unassigned'),
(2460, '[LUCENE-5180] ShingleFilter should make shingles from trailing holes', 'Michael McCandless', 'Michael McCandless'),
(2471, '[LUCENE-5166] PostingsHighlighter fails with IndexOutOfBoundsException', 'Manuel Amoabeng', 'Unassigned'),
(2590, '[LUCENE-5033] SlowFuzzyQuery appears to fail with edit distance >=3 in some cases', 'Tim Allison', 'Unassigned'),
(2638, '[LUCENE-4976] PersistentSnapshotDeletionPolicy should save to a single file', 'Michael McCandless', 'Michael McCandless'),
(2710, '[LUCENE-4897] Add a sugar API for traversing categories.', 'crocket', 'Shai Erera'),
(2720, '[LUCENE-4883] Hide FieldCache behind an UninvertingFilterReader', 'Alan Woodward', 'Alan Woodward'),
(2722, '[LUCENE-4881] Add a set iterator to SentinelIntSet', 'David Smiley', 'David Smiley'),
(2726, '[LUCENE-4877] Fix analyzer factories to throw exception when arguments are invalid', 'Robert Muir', 'Unassigned'),
(2751, '[LUCENE-4852] BaseStoredFieldsFormatTestCase', 'Robert Muir', 'Unassigned'),
(2816, '[LUCENE-4782] Let the NaiveBayes classifier have a fallback docCount method if codec doesn\'t support Terms#docCount()', 'Tommaso Teofili', 'Tommaso Teofili'),
(2953, '[LUCENE-4630] add a system property to allow testing of suspicious stuff', 'Hoss Man', 'Unassigned'),
(2975, '[LUCENE-4607] Add estimateDocCount to DocIdSetIterator', 'Simon Willnauer', 'Unassigned'),
(3035, '[LUCENE-4540] Allow packed ints norms', 'Robert Muir', 'Robert Muir'),
(3158, '[LUCENE-4409] implement javadocs linting with eclipse ecj compiler', 'Robert Muir', 'Uwe Schindler'),
(3167, '[LUCENE-4397] TestIndexWriterWithThreads.testRollbackAndCommitWithThreads is sometimes very very slow', 'Robert Muir', 'Unassigned'),
(3313, '[LUCENE-4227] DirectPostingsFormat, storing postings as simple int[] in memory, if you have tons of RAM', 'Michael McCandless', 'Michael McCandless'),
(3459, '[LUCENE-4059] prepare-webpages breaks the build if there are none URI complement characters in the path', 'Greg Bowyer', 'Uwe Schindler'),
(3474, '[LUCENE-4043] Add scoring support for query time join', 'Martijn van Groningen', 'Unassigned'),
(3500, '[LUCENE-4013] DWPTpool shouldnt be public (its methods have pkg-private parameters)', 'Robert Muir', 'Michael McCandless'),
(3501, '[LUCENE-4012] Make all query classes serializable with Jackson, and provide a trivial query parser to consume them', 'Benson Margulies', 'Unassigned'),
(3625, '[LUCENE-3877] Lucene should not call System.out.println', 'Michael McCandless', 'Michael McCandless'),
(3626, '[LUCENE-3876] TestIndexWriterExceptions fails (reproducible)', 'Dawid Weiss', 'Unassigned'),
(3675, '[LUCENE-3825] Please push maven snapshots to repositories.apache.org again', 'Benson Margulies', 'Steve Rowe'),
(3710, '[LUCENE-3786] Create SearcherTaxoManager', 'Shai Erera', 'Michael McCandless'),
(3789, '[LUCENE-3703] DirectoryTaxonomyReader.refresh misbehaves with ref counts', 'Shai Erera', 'Shai Erera'),
(3797, '[LUCENE-3694] DocValuesField should not overload setInt/setFloat etc', 'Robert Muir', 'Michael McCandless'),
(3938, '[LUCENE-3539] IndexFormatTooOld/NewExc should try to include fileName + directory when possible', 'Michael McCandless', 'Michael McCandless'),
(4052, '[LUCENE-3414] Bring Hunspell for Lucene into analysis module', 'Chris Male', 'Chris Male'),
(4218, '[LUCENE-3228] build should allow you (especially hudson) to refer to a local javadocs installation instead of downloading', 'Robert Muir', 'Steve Rowe'),
(4269, '[LUCENE-3176] TestNRTThreads test failure', 'Robert Muir', 'Michael McCandless'),
(4274, '[LUCENE-3171] BlockJoinQuery/Collector', 'Michael McCandless', 'Unassigned'),
(4306, '[LUCENE-3139] LuceneTestCase.afterClass does not print enough information if a temp-test-dir fails to delete', 'Shai Erera', 'Shai Erera'),
(4318, '[LUCENE-3123] TestIndexWriter.testBackgroundOptimize fails with too many open files', 'Doron Cohen', 'Unassigned'),
(4325, '[LUCENE-3116] pendingCommit in IndexWriter is not thoroughly tested', 'Uwe Schindler', 'Unassigned'),
(4400, '[LUCENE-3034] If you vary a setting per round and that setting is a long string, the report padding/columns break down.', 'Mark Miller', 'Mark Miller'),
(4415, '[LUCENE-3019] FVH: uncontrollable color tags', 'Koji Sekiguchi', 'Koji Sekiguchi'),
(4489, '[LUCENE-2936] score and explain don\'t match', 'Koji Sekiguchi', 'Hoss Man'),
(4499, '[LUCENE-2924] fix getting started / demo docs', 'Michael McCandless', 'Robert Muir'),
(4517, '[LUCENE-2905] Sep codec writes insane amounts of skip data', 'Robert Muir', 'Unassigned'),
(4535, '[LUCENE-2886] Adaptive Frame Of Reference', 'Renaud Delbru', 'Unassigned'),
(4565, '[LUCENE-2856] Create IndexWriter event listener, specifically for merges', 'Jason Rutherglen', 'Unassigned'),
(4600, '[LUCENE-2818] abort() method for IndexOutput', 'Earwin Burrfoot', 'Unassigned'),
(4661, '[LUCENE-2753] IndexReader.listCommits should return a List and not an abstract Collection', 'Shai Erera', 'Shai Erera'),
(4725, '[LUCENE-2684] it\'s not possible to access sub-query\'s freq information if BooleanScorer is use', 'Michael McCandless', 'Unassigned'),
(4844, '[LUCENE-2558] Use sequence ids for deleted docs', 'Jason Rutherglen', 'Unassigned'),
(4920, '[LUCENE-2476] Constructor of IndexWriter let\'s runtime exceptions pop up, while keeping the writeLock obtained', 'Cservenak, Tamas', 'Michael McCandless'),
(4921, '[LUCENE-2475] Incorrect Bounding Box calculation results in the exclusion of valid data locations', 'Julian Atkinson', 'Unassigned'),
(4949, '[LUCENE-2444] move contrib/analyzers to modules/analysis', 'Robert Muir', 'Robert Muir'),
(4973, '[LUCENE-2409] add a tokenfilter for icu transforms', 'Robert Muir', 'Robert Muir'),
(4979, '[LUCENE-2402] Add an explicit method to invoke IndexDeletionPolicy', 'Shai Erera', 'Shai Erera'),
(4983, '[LUCENE-2398] Improve tests to work easier from IDEs', 'Robert Muir', 'Robert Muir'),
(4994, '[LUCENE-2387] IndexWriter retains references to Readers used in Fields (memory leak)', 'Ruben Laguna', 'Michael McCandless'),
(5167, '[LUCENE-2206] integrate snowball stopword lists', 'Robert Muir', 'Robert Muir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lucene_rss_issues`
--
ALTER TABLE `lucene_rss_issues`
  ADD PRIMARY KEY (`issue_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
